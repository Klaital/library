<?php

function lookupUpcUpcdatabaseDotCom($code, $key) {
	// Default: return value of false indicates lookup failure
	return false;
}

function lookupUpcUpcdatabaseDotOrg($code, $key) {
	// Default: return value of false indicates lookup failure
	return false;
}

function lookupUpcSearchupcDotCom($code, $key) {
	// Default: return value of false indicates lookup failure
	return false;
}

function lookupUpcAmazonMws($code, $credentials) {
	// Default: return value of false indicates lookup failure
	return false;
}
