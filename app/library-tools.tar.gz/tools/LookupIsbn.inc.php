<?php

function lookupIsbnGoogleBook($code, $key) {
	
	// Default: return value of false indicates lookup failure
	return false;	
}

function lookupIsbnAmazonMws($code, $credentials) {
	
	// Default: return value of false indicates lookup failure
	return false;
}


