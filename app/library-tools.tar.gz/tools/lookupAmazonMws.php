<?php
require_once('db.inc.php');
require_once('MarketplaceWebServiceProducts/Client.php');

function lookupCodeAmazonProductsApi($codes, $code_type='UPC', $mws_cslient) {

}
